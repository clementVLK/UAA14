﻿using System;

namespace ACT00_REVISION
{
    class Program
    {
        static void Main(string[] args)
        {
            // déclaration des variables.... COMPLETER AVEC CE QUI MANQUE

            string rep;
            
            double c1 = 0;
            double c2 = 0;
            double c3 = 0;
            bool ok = false;
            string infos = "";

            Console.WriteLine("Testez les polygones !");
            //On recommence tant que désiré
            do
            {
                //lecture des 3 côtés => A FAIRE
                c1 = lireDouble(1);
                c2 = lireDouble(1);
                c3 = lireDouble(1);

               MethodesDuProjet.OrdonneCotes(ref c1, ref c2, ref c3);
                // ...
                // série de test (voir consignes)
                if (MethodesDuProjet.Triangle(c1, c2, c3)) // si on a un triangle...
                {
                    MethodesDuProjet.PrepareAffchage(out infos, true, "triangle");
                    Console.WriteLine(infos);


                    if (MethodesDuProjet.Equi(c1, c2, c3))
                    {
                        MethodesDuProjet.PrepareAffchage(out infos, true, "equilateral");
                        Console.WriteLine(infos);
                    } 
                    else
                    {
                        // vérification triangle rectangle
                        if (MethodesDuProjet.TriangleRectangle(ref c1, ref c2, c3))
                        {
                            MethodesDuProjet.PrepareAffchage(out infos, true, "rectangle");
                            Console.WriteLine(infos);
                        }
                        else
                        {
                            MethodesDuProjet.PrepareAffchage(out infos, false, "rectangle");
                            Console.WriteLine(infos);
                        }

                        // vérification isocèle
                        MethodesDuProjet.Isocele(c1, c2, c3, out ok);

                        if (ok)
                        {
                            MethodesDuProjet.PrepareAffchage(out infos, true, "isocele");
                            Console.WriteLine(infos);
                        }
                    }
                }
                else // ce n'est pas un triangle
                {
                    MethodesDuProjet.PrepareAffchage(out infos, false, "triangle");
                    Console.WriteLine(infos);
                }
                // reprise ?
                Console.WriteLine("Voulez-vous tester un autre polygône ? (Tapez espace)");
                rep = Console.ReadLine();
            } while (rep == " ");
        }
        //Récupération d'une donnée fournie par l'utilisateur en 'double' : on suppose qu'il ne se trompe pas !
        static double lireDouble(int numeroCote)
        {
            double cote;
            Console.Write("Tapez la valeur du côté " + numeroCote + " : ");
            cote = double.Parse(Console.ReadLine());
            return cote;
        }
    }
}
